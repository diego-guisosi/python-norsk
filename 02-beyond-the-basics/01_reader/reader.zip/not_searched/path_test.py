def found():
    print('Python found')
